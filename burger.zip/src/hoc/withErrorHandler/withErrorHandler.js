import React, { Component } from 'react';

import Modal from '../../components/UI/Modal/Modal';
import Aux from '../Auxx/auxx';

const withErrorHandler = ( WrappedComponent, axios ) => {
    return class extends Component {
        state = {
            error: null
        }

        componentWillMount () {
           this.reqInterceptor = axios.interceptors.request.use(req => {
                this.setState({error: null});
                return req;
            });
           this.resInterceptor = axios.interceptors.response.use(res => res, error => {
                this.setState({error: error});
            });
        }

        componentWillUnmount () {
            axios.interceptors.request.eject(this.reqInterceptor);
            axios.interceptors.response.eject(this.resInterceptor);
        }    

        errorConfirmedHandler = () => {
            this.setState({error: null});
        }

        render () {
            return (
                <Aux>
                    <Modal 
                        show={this.state.error}
                        modalClosed={this.errorConfirmedHandler}>
                        {this.state.error ? this.state.error.message : null}
                    </Modal>
                    <WrappedComponent {...this.props} />
                </Aux>
            );
        }
    }
}

export default withErrorHandler;



// import React, { Component } from 'react';

// import Modal from '../../components/UI/Modal/Modal';
// import Aux from '../Auxx/auxx';

// const WithErrorHandler = (WrappedComponent, axios) => {
//     const [ error, setError] = useState({error:null});

//     useEffect(() => {

//         axios.interceptors.request.use( req => {
//             setError({
//                 error: null
//             });
//             return req;
//         });

//         axios.interceptors.response.use(res => res, error => {
//           setError({
//               error: error
//           });
          
//         });
//     //   return () => {
        
//     //   }
//     }, []);

//     const errorComfiredHandler = () => {
//         setError({error: null});
//     }
    
//   return (
//     props => {
//         return ( 
//            <Aux>
//                 <Modal show={error} clicked={errorComfiredHandler}>
//                    {error ? error.message : null}
//                 </Modal>
//                 <WrappedComponent {...props} />
//            </Aux>
//         );
//     }
//   );
// }

// export default WithErrorHandler