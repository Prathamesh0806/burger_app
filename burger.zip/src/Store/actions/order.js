import * as actionTypes from '../actions/actionTypes';
import axios from '../../axios-orders';

export const purchesBurgerSuccess = (id, orderData) => {
    return {
        type: actionTypes.PURCHASE_BURGER_SUCCESS,
        orderId: id,
        orderData: orderData
    };
};

export const purchesBurgerFail = (error) => {
    return {
        type: actionTypes.PURCHASE_BURGER_FAILED,
        error: error
    };
};

export const purchesBurgerStart = () => {
    return {
        type: actionTypes.PURCHASE_BURGER_START
    };
};

export const purchesBurger = (orderData, token) => {
    return dispatch => {
        dispatch(purchesBurgerStart());
        axios.post('/orders.json?auth='+token, orderData)
        .then(response => 
            // console.log(response.data.name)
           dispatch(purchesBurgerSuccess(response.data.name, orderData))
        
        )
        .catch(err =>
           dispatch(purchesBurgerFail(err)) 
        ); 

        
    };
};

export const purchesInit = () => {
    return {
        type: actionTypes.PURCHASE_INIT
    };
};

export const fetchOrderSuccess = (orders) => {
    return {
        type: actionTypes.PURCHAES_ORDERS_SUCCESS,
        orders: orders
    };
};

export const fetchOrderFailed = (error) => {
    return {
        type: actionTypes.PURCHAES_ORDERS_FAILED,
        error: error
    };
};

export const fetchOrderStart = () => {
    return {
        type: actionTypes.PURCHASE_ORDERS_START
    };
};

export const fetchOrders = (token, userId) => {
    return dispatch => {
        dispatch(fetchOrderStart());
        const queryParams = '?auth=' + token + '&orderBy="userId"&equalTo="' + userId + '"';
         axios.get('/orders.json'+ queryParams)
        .then(res => {
            const fetchOrders = [];
            for (let key in res.data) {
                fetchOrders.push({
                    ...res.data[key],
                    id : key
                });
            }
            dispatch(fetchOrderSuccess(fetchOrders));
           
        })
        .catch(err => {
           dispatch(fetchOrderFailed(err));
        });

    }
}