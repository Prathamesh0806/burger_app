import * as actionTypes from '../actions/actionTypes';

const initialSate = {
    order: [],
    loading: false,
    purchased: false
};

const reducer = (state=initialSate, action) => {
  switch (action.type) {

    case actionTypes.PURCHASE_INIT:
        return {
            ...state,
            purchased: false
        }

    case actionTypes.PURCHASE_BURGER_START:
        return {
            ...state,
            loading: true
        }
        
    case actionTypes.PURCHASE_BURGER_SUCCESS:
        const newOrder = {
            ...action.orderData,
            id: action.orderId
        }
        return {
            ...state,
            loading: false,
            purchased: true,
            order: state.order.concat(newOrder)
        }

    case actionTypes.PURCHASE_BURGER_FAILED:
        return {
            ...state,
            loading: false,
        }

    case actionTypes.PURCHASE_ORDERS_START:
        return {
            ...state,
            loading: true,
        };

    case actionTypes.PURCHAES_ORDERS_SUCCESS:
        return {
           ...state,
           order: action.orders, 
           loading: false
        };

    case actionTypes.PURCHAES_ORDERS_FAILED:
        return {
            ...state,
            loading: false
        }

    default :
        return state;
  }
}

export default reducer;