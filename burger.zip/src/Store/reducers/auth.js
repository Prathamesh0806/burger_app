import * as actionsTypes from '../actions/actionTypes';

const initialState = {
    token: null,
    userId: null,
    error: null,
    loading: false,
    authRedirect: '/auth'
}


const reducer = (state = initialState, action) => {

    switch (action.type) {
        case actionsTypes.AUTH_START:
            return {
                ...state,
                error: null,
                loading: true
            } 

        case actionsTypes.AUTH_SUCCESS:
            return {
                token: action.idToken,
                userId: action.userId,
                error: null,
                loading: false
            }
        
        case actionsTypes.AUTH_FAILED:
            return {
                error: action.error,
                loading: false
            }
           
        case actionsTypes.AUTH_LOGOUT:
            return {
                ...state,
                token: null,
                userId: null
            }; 

        case actionsTypes.SET_AUTH_REDIRECT_PATH:
            return {
                ...state,
                authRedirect: action.redPath
            }

        default :
            return state;
    }
}

export default reducer;