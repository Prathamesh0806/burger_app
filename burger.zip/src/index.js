import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { configureStore ,combineReducers} from '@reduxjs/toolkit';
import { Provider } from 'react-redux';
import logger from 'redux-logger';
import  thunkMiddleware  from 'redux-thunk';

import App from './App';
import burgerBuilderReducer from './Store/reducers/burgerBuilder';
import orderReducer from './Store/reducers/order';
import authReducer from './Store/reducers/auth';
import './index.css';

import reportWebVitals from './reportWebVitals';

const middleware = [thunkMiddleware, logger];

const rootReducer = combineReducers({
  burgerBuilder: burgerBuilderReducer,
  order: orderReducer,
  authRed: authReducer
});

const store = configureStore ({
  reducer : rootReducer,
  middleware: [...middleware]
});

const app = (
  <Provider store={ store }>
    <BrowserRouter >
      <React.StrictMode>
        <App />
      </React.StrictMode>
    </BrowserRouter>
  </Provider>
);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(app);

// ReactDOM.render(<React.StrictMode><App /></React.StrictMode>,document.getElementById('root'));


reportWebVitals();
