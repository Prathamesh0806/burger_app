import React from 'react';

import BuildControl from './BuildControls/BuildControls';
import './BuildControls.css';

const controls = [
    {label: 'Salad', type: 'asalad'},
    {label: 'Bacon', type: 'bacon'},
    {label: 'Cheese', type: 'cheese'},
    {label: 'Meat', type: 'meat'}
];

const buildControls = props => {

    return (
        <div className='BuildControls'>
            <p>Current Price: <strong>{props.price.toFixed(2)}</strong></p>
            {
                controls.map(crt => 
                    <BuildControl 
                        key={crt.label} 
                        label={crt.label}
                        added={() =>props.ingredintAdded(crt.type)}
                        removed={() =>props.ingredintRemoved(crt.type)}
                        disabled={props.disabled[crt.type]}
                    />
                )
            }
            <button 
            className='OrderButton'
            disabled={!props.purchasable}
            onClick={props.ordered}
            >
           { props.isAuth ? 'ORDER NOW' : 'SIGN UP TO ORDER'}
            </button>
        </div>
    );
}

export default buildControls;
