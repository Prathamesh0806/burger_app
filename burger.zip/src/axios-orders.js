import axios from "axios";

const instance = axios.create({
    baseURL: 'https://react-burger-app-71d6d-default-rtdb.firebaseio.com/'
});

export default instance;